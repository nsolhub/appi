<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

	 public function __construct() {
            parent::__construct(); 
		$this->load->model("masterModel");
	}

	public function index()
	{
		echo "go to API function please!";
	}

	public function showAllAgentsAPI(){
		$data["arr"] = array();
		$token = $this->input->get('token');

		if($token === "abc123"){

		$data['allAgents'] = $this->masterModel->fetch_all_agents();
		print_r(json_encode($data['allAgents']));
		}else{
			echo "validation failed";
		}
		
		//echo "<pre>";
		//print_r($data['allAgents']);
		
	}

	public function callAgentAPI(){
		

			
			//$agentid = $this->input->get("agentid");
		$content = file_get_contents('http://localhost/raheel/ci/api/showAllAgentsAPI?token=abc123');

		//$data = array();
		$data = json_decode($content);

		
		
		print_r($data);
		
	}
	}
