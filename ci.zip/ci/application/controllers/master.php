<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master extends CI_Controller {

	
	public function index()
	{
		echo "go to function please!";
	}

	public function showAllAgents(){
		$this->load->model("masterModel");
		$data['allAgents'] = $this->masterModel->fetch_all_agents();
		$this->load->view("master", $data);
	}
}
