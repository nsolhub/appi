<?php



class masterModel extends CI_Model {


	public function __construct()	{
  		$this->load->database(); 
	}

	public function fetch_all_agents(){

		$query = $this->db->get( "agents");
		return $query->result();
	}

	public function fetch_one_agents($id){

		$query = $this->db->query('SELECT * FROM agents WHERE AGENT_CODE="'.$id.'"');

		return $query->result();
	}

}