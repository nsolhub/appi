<h1> Pakistan Master </h1>

<?php 

?>
<table border="1">
	<thead>
		<td>ID</td>
		<td>Name </td>
		<td>Area </td>
		<td>Commission </td>
		<td>Phone </td>
		<td> Country </td>
	</thead>
	<tbody>
<?php	
	foreach($allAgents as $showAgents):
	 echo "<tr>
	 		<td> {$showAgents->AGENT_CODE}</td>
	 		<td> {$showAgents->AGENT_NAME}</td>
	 		<td> {$showAgents->WORKING_AREA}</td>
	 		<td> {$showAgents->COMMISSION}</td>
	 		<td> {$showAgents->PHONE_NO}</td>
	 		<td> {$showAgents->COUNTRY}</td>
	 		</td>";
	endforeach;
	?>
	
	</tbody></table>




